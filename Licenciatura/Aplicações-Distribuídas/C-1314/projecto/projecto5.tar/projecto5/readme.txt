fc43538 Ines Matos
fc43536 Tiago Moucho
Grupo ad004


O problema deste projecto é que o servidor e o cliente comunicam bem com o primeiro comando inserido pelo cliente, mas ao segundo comando, o servidor não recebe a mensagem, apenas o tamanho(apesar do cliente indicar que enviou e leu), o que se podia presumir que é por algum malloc não feito, mas não conseguimos identificar verdadeiramente o problema.
