package spacegame;

public class Bomb extends AbstractGameElement {

	/**
	 * inicializa o tipo Bomb
	 * @param initialPosition
	 */
	public Bomb(Coord2D initialPosition) {
		super(initialPosition, "bomb.gif");

	}

	/*+
	 * (non-Javadoc)
	 * @see spacegame.AbstractGameElement#step()
	 */
	@Override
	public void step(){
		
	}
}








